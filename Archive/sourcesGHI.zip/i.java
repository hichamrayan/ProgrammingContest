 // JNJD 2012
//  Problem I : Judge Solution
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class I {

    static Scanner in;
    static PrintWriter out;
    static long comb[][]=new long[21][21];

     static long comb(int k,int n)
    {
         if(k>n)return 0;
         if(k==0)return 1;
         if(k==1)return n;
         return (n*comb[k-1][n-1])/k;
    }

    public static void main(String[] args) throws Exception
    {
        in=new Scanner(new File("I.in"));
        out=new PrintWriter("I.out");
        for(int k=0;k<=9;k++)
            for(int n=0;n<=9;n++)
            comb[k][n]=comb(k,n);
        int c=in.nextInt();
      int p=0;
        for(int i=0;i<c;i++)
       {
        p=in.nextInt();
        int pos[]=new int[p+1];
        for(int j=0;j<p;j++)
            pos[j]=in.nextInt();
        pos[p]=9;
        long res=1;
        for(int j=0;j<p;j++)
            res=res*comb[pos[j]][pos[j+1]];
        System.out.println();
        System.out.print(res);
        }
    
    }
    }
