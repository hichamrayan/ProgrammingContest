 // JNJD 2012
//  Problem G : Judge Solution
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class g {

    static Scanner in;
    static PrintWriter out;

    public static void main(String[] args) throws Exception
    {
        in=new Scanner(new File("g.in"));
        out=new PrintWriter("g.out");
       int c=in.nextInt();
       int n,p;
       String Name[]={"Ali","Badr"};
        p=in.nextInt();n=in.nextInt();
        System.out.print(Name[n%3==0?1-p:p]);
       for(int i=1;i<c;i++)
       {
           p=in.nextInt();n=in.nextInt();
           System.out.println();
        System.out.print(Name[n%3==0?1-p:p]);

       }
    }
    }
