 // JNJD 2012
//  Problem H : Judge Solution
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class h {

    static Scanner in;
    static PrintWriter out;
    static int comb[][]=new int[11][11];


    static int trace(int n,int m)
    {
        if(n==0||m==0) return 1;
        if(n==1||m==1) return n+m;
        return comb[n-1][m]+comb[n][m-1];
    }
    public static void main(String[] args) throws Exception
    {
        in=new Scanner(new File("h.in"));
        out=new PrintWriter("h.out");
        for(int k=0;k<=10;k++)
            for(int n=0;n<=10;n++)
            comb[k][n]=trace(k,n);
        int c=in.nextInt();
       int n,m,a,b;
        n=in.nextInt();m=in.nextInt();
        a=in.nextInt();b=in.nextInt();
        System.out.print(comb[a][b]*comb[n-a][m-b]);
        for(int i=1;i<c;i++)
       {
        n=in.nextInt();m=in.nextInt();
        a=in.nextInt();b=in.nextInt();
        System.out.println();
         System.out.print(comb[a][b]*comb[n-a][m-b]);
        }
    
    }
    }
