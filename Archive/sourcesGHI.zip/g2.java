 // JNJD 2012
//  Problem G : Judge Solution (recursion && dynamic programming)
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

/*
 @author Hicham
 */
public class g {

    static Scanner in;
    static PrintWriter out;
    static int gamb[][]=new int[10001][2];


    static int win(int n,int p)
    {
       if(n<=2) {return p;}
       int res1,res2;
       //res1=win(n-1,1-p);
       res1=gamb[n-1][1-p];
       if(res1==p) return res1;
       //res2=win(n-2,1-p);
       res2=gamb[n-2][1-p];
       return res2;
    }

    public static void main(String[] args) throws Exception
    {
        in=new Scanner(new File("g.in"));
        out=new PrintWriter("g.out");
        for(int i=1;i<1000;i++)
        {gamb[i][1]= win(i,1);gamb[i][0]= win(i,0);}
       int c=in.nextInt();
       int n,p;
       String Name[]={"Ali","Badr"};
        p=in.nextInt();n=in.nextInt();
        System.out.print(Name[win(n,p)]);
       for(int i=1;i<c;i++)
       {
           p=in.nextInt();n=in.nextInt();
           System.out.println();
        System.out.print(Name[win(n,p)]);

       }
    }
    }
