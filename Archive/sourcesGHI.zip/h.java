 // JNJD 2012
//  Problem H : Judge Solution
// 1<=n,m<=10 for greater values you can use BigInteger instead of long
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author backup
 */
public class H {

    static Scanner in;
    static PrintWriter out;
    static long comb[][]=new long[21][21];

     static long comb(int k,int n)
    {
         if(k>n)return 0;
         if(k==0)return 1;
         if(k==1)return n;
         return (n*comb[k-1][n-1])/k;
    }

    public static void main(String[] args) throws Exception
    {
        in=new Scanner(new File("h.in"));
        out=new PrintWriter("h.out");
        for(int k=0;k<=10;k++)
            for(int n=0;n<=10;n++)
            comb[k][n]=comb(k,n);
        int c=in.nextInt();
       int n,m,a,b;
        n=in.nextInt();m=in.nextInt();
        a=in.nextInt();b=in.nextInt();
        System.out.print(comb[a][a+b]*comb[n-a][n+m-a-b]);
        for(int i=1;i<c;i++)
       {
        n=in.nextInt();m=in.nextInt();
        a=in.nextInt();b=in.nextInt();
        System.out.println();
        System.out.print(comb[a][a+b]*comb[n-a][n+m-a-b]);
        }
    
    }
    }
